package wissen.rest.services;

public interface EmailService {

    Boolean sendEmail(EmailEntity e);
}
